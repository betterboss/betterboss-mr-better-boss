// =============================================================================
// Better Boss — DocFill Content Script
// https://mybetterboss.ai
//
// Injects a side panel on JobTread document pages. User fills in client info,
// extension merges it with saved business profile + template, user copies
// the rendered text and pastes into JobTread Description / Footer fields.
//
// JobTread formatting:
//   *bold*  ^italic^  _underline_  ~strikethrough~
//   # H1  ## H2  ### H3  #### H4
//   - bullet  1. numbered  > quote  --- hr  [text](url)
// =============================================================================

(function () {
  'use strict';

  const BUTTON_ID = 'bb-autofill-btn';
  const PANEL_ID  = 'bb-autofill-panel';
  const BRAND     = 'Better Boss';

  let currentJobInfo = null;
  let currentCustomerInfo = null;

  // ---- Helpers ----

  function log(...a) { console.log('[Better Boss]', ...a); }

  function debounce(fn, ms) {
    let t;
    return function (...args) { clearTimeout(t); t = setTimeout(() => fn.apply(this, args), ms); };
  }

  function getInitials(name) {
    if (!name) return 'BB';
    const p = name.trim().split(/\s+/);
    return p.length >= 2
      ? (p[0][0] + p[p.length - 1][0]).toUpperCase()
      : p[0].substring(0, 2).toUpperCase();
  }

  function esc(s) {
    return (s || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  // ---- Storage (with error handling) ----

  function getStored() {
    return new Promise((resolve) => {
      try {
        chrome.storage.sync.get(null, (r) => {
          if (chrome.runtime.lastError) {
            log('Storage read error:', chrome.runtime.lastError);
            resolve({});
          } else {
            resolve(r || {});
          }
        });
      } catch (e) {
        log('Storage exception:', e);
        resolve({});
      }
    });
  }

  // ---- Page Detection ----

  const DOC_PATHS = [
    '/jobs/','/documents/','/invoices/','/estimates/','/proposals/',
    '/contracts/','/purchase-orders/','/change-orders/','/work-orders/',
    '/bills/','/budget','/quotes/'
  ];
  const EXCLUDE_PATHS = ['/settings','/plans','/catalog'];

  function isRelevantPage() {
    const p = window.location.pathname;
    return DOC_PATHS.some(d => p.includes(d));
  }
  function isExcludedPage() {
    const p = window.location.pathname;
    return EXCLUDE_PATHS.some(d => p.includes(d));
  }

  // ---- Info Extraction ----

  function extractJobInfo() {
    const info = { jobName:'', jobNumber:'', jobAddress:'', jobId:'' };
    try {
      for (const h of document.querySelectorAll('h1, h2')) {
        const t = h.textContent.trim();
        if (t.length > 2 && t.length < 200) { info.jobName = t; break; }
      }
      if (!info.jobName) {
        const m = document.title.match(/^(.+?)(?:\s*[-|]\s*JobTread)?$/i);
        if (m) info.jobName = m[1].trim();
      }
      const nm = document.body.innerText.match(/(?:Job\s*#?\s*|#)(\d{3,})/i);
      if (nm) info.jobNumber = nm[1];
      const id = window.location.pathname.match(/\/jobs\/([^/]+)/);
      if (id) info.jobId = id[1];
    } catch (e) { log('extractJobInfo error:', e); }
    return info;
  }

  function extractCustomerInfo() {
    const info = { customerName:'', company:'', email:'', phone:'' };
    try {
      const txt = document.body.innerText;
      const em = txt.match(/[\w.+-]+@[\w-]+\.[\w.]+/);
      if (em) info.email = em[0];
      const ph = txt.match(/\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
      if (ph) info.phone = ph[0];
    } catch (e) { log('extractCustomerInfo error:', e); }
    return info;
  }

  // ---- Template Engine ----

  function getDefaultDescTemplate() {
    return `*JobTread Implementation Agreement \u2014 *^{{company}}^**
*Client:* *^{{company}}^* (\u201CClient\u201D) \u2022 *Contact:* *^{{customerName}}^*
*Provider:* {{bizName}} (\u201CProvider\u201D)
*Project:* Full JobTread build-out operating system for remodeling and construction
*Term:* 30 business day implementation from kickoff
*Total Contract Value:* *$10,000 USD*
*Financing:* See Section 6
##1) Objective
Deploy a single, structured JobTread OS that speeds proposals, reduces chaos, and gives clear visibility across jobs and finances.
##2) Scope of Work
####2.1 Meetings & Communication
- 2-hour kickoff meeting
- 1 midway checkpoint meeting
- 1 final meeting
- Chat/message communication in JobTread with 24-hour email support
####2.2 Implementation Schedule
Custom implementation schedule built inside JobTread to track progress and milestones.
####2.3 Cost Catalog Build
Complete cost catalog build including suppliers, labor, materials, cost groups, product and material catalog uploaded, standardized, and linked to cost codes.
####2.4 Job Costing Framework
Job costing review including units, cost codes, and cost types configured for accurate project tracking.
####2.5 Custom Views
Custom views across all modules including jobs, customers, catalog, and more for streamlined navigation.
####2.6 Estimating Engine
- Parameters and formulas for quantity formulas in estimate templates
- Measurement integration (RENDR, Hover, or EagleView) OR setup for manual parameter input
- 3-5 estimate templates with cost groups, formulas, and parameter fields for fast, accurate range-based pricing
####2.7 Document Templates
Document template build-out including details, design, and custom cover PDFs. Proposals, Closeout Packets, Certificates of Completion, Contracts, and Change Orders configured and branded.
####2.8 Dashboards
1-2 custom dashboards with live metrics by role\u2014estimating accuracy, job costs, and pipeline status.
####2.9 Automation Suite
Up to 5 custom notifications OR 2-4 workflows as needed for client and trade partner communication including reminders, scheduling, and follow-ups.
####2.10 SOP Guides
5-10 SOP guides with refined standard operating procedures embedded directly in JobTread, built for repeatability and automation.
####2.11 Integration Review
Integration review (QuickBooks Online, etc.) to ensure connection is solid. Note: Provider is not an accountant but will verify integration functionality.
####2.12 Training & Handoff
Role-based videos, SOP reference map, and admin maintenance guide for full control post-launch.
##3) Scope Exclusions (Priced Separately)
- Custom API development
- Data migrations (e.g., CoConstruct migration = +$1,000 USD)
- GHL CRM integration
- Build out of integrated tools
- In-house takeoff tooling
##4) Process Assumptions
- Estimating: fixed cost and range-based models
- Standard JobTread features only; no external code or plug-ins
- Can help implement tools like RENDR or prebuilt integrations with JobTread
##5) Timeline (30 Business Days)
- Week 1: Kickoff, access setup, system mapping
- Week 2: Build templates, workflows, and automations; midpoint review
- Week 3: Finalize documents, dashboards, and schedules
- Week 4: QA, training videos, admin guide, go-live
##6) Pricing & Financing
*Fixed Fee*: $10,000 USD
*Financing options:*
6 mo: $1,666.67/mo \u2014 no interest
12 mo: $879.13/mo \u2014 ~$549.56 interest
36 mo: $322.63/mo \u2014 ~$1,614.90 interest
^Final terms subject to credit and approvals.^
##7) Payment Terms
- *100% due at kickoff* to schedule and start work
- If financed, the financing schedule replaces upfront payment
##8) Client Responsibilities
- Add Provider as a JobTread user and grant full access within 2 business days
- Provide reference materials (specs, selections, budgets, contract templates)
- Designate a decision-maker for reviews/approvals within 2 business days
- Attend kickoff and midpoint review
##9) Change Orders
Any change that adds scope, exceeds revision limits, or extends the timeline will require a change order and separate pricing.
##10) Support & Additional Work
- Post-go-live support available at an additional fee
- New projects outside this scope require a separate SOW
##11) Intellectual Property
- Client owns deliverables upon full payment
- Provider retains reusable frameworks
- No disclosure of Client data without consent
##12) Data Protection
Client is responsible for independent backups. Provider is not liable for data loss from Client actions or third-party outages.
##13) Limitation of Liability
Liability capped at total fees paid in prior 6 months. No consequential or special damages.
##14) Force Majeure
No liability for delays caused by events outside reasonable control.
##15) Confidentiality
Non-public information remains confidential and must be handled with reasonable care.
##16) Indemnification
Client indemnifies Provider against third-party claims from misuse or breach.
##17) Dispute Resolution & Governing Law
30-day informal negotiation, then binding arbitration in Denver, CO under AAA rules. Colorado law governs.
##18) Entire Agreement & Amendments
This document is the full agreement; changes require written approval.
##19) Counterparts & E-Signature
This agreement may be signed electronically and in counterparts.
##20) Acceptance & Signature
This Agreement is binding upon Client\u2019s signature below. *{{bizName}}\u2019s acceptance is deemed upon (a) commencement of services or (b) receipt of the first payment.* No additional Provider signature required.`;
  }

  function getDefaultFooterTemplate() {
    return '{{#customerName}}*Prepared for:* {{customerName}}{{/customerName}}' +
      '{{#company}} | *{{company}}*{{/company}}' +
      '{{#jobName}} | Project: {{jobName}}{{/jobName}}' +
      '{{#jobNumber}} | Job #{{jobNumber}}{{/jobNumber}}' +
      '\n{{#bizName}}*{{bizName}}*{{/bizName}}' +
      '{{#bizPhone}} | {{bizPhone}}{{/bizPhone}}' +
      '{{#bizEmail}} | {{bizEmail}}{{/bizEmail}}' +
      '{{#bizWebsite}} | {{bizWebsite}}{{/bizWebsite}}' +
      '{{#bizLicense}} | Lic #{{bizLicense}}{{/bizLicense}}';
  }

  function render(template, data) {
    let r = template;
    r = r.replace(/\{\{#(\w+)\}\}([\s\S]*?)\{\{\/\1\}\}/g, (_, k, c) => {
      return (data[k] && data[k].toString().trim())
        ? c.replace(/\{\{(\w+)\}\}/g, (__, kk) => data[kk] || '')
        : '';
    });
    r = r.replace(/\{\{(\w+)\}\}/g, (_, k) => data[k] || '');
    return r.replace(/\n{3,}/g, '\n\n').trim();
  }

  // ---- Clipboard (with validation) ----

  async function copyText(text, btn) {
    let ok = false;
    try {
      await navigator.clipboard.writeText(text);
      ok = true;
    } catch (_) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.cssText = 'position:fixed;left:-9999px;opacity:0';
        document.body.appendChild(ta);
        ta.select();
        ok = document.execCommand('copy');
        document.body.removeChild(ta);
      } catch (__) { ok = false; }
    }
    const orig = btn.textContent;
    if (ok) {
      btn.textContent = 'Copied!';
      btn.classList.add('bb-btn--copied');
    } else {
      btn.textContent = 'Failed — select & copy manually';
      btn.classList.add('bb-btn--error');
    }
    setTimeout(() => {
      btn.textContent = orig;
      btn.classList.remove('bb-btn--copied', 'bb-btn--error');
    }, 2000);
  }

  // ---- Floating Button ----

  function createFAB() {
    if (document.getElementById(BUTTON_ID)) return;
    const el = document.createElement('div');
    el.id = BUTTON_ID;
    el.innerHTML = `<button class="bb-fab" title="${BRAND} DocFill" aria-label="Open ${BRAND} DocFill panel"><span class="bb-fab__text">BB</span></button>`;
    el.addEventListener('click', togglePanel);
    document.body.appendChild(el);
  }

  // ---- Panel ----

  function togglePanel() {
    const ex = document.getElementById(PANEL_ID);
    if (ex) { ex.remove(); return; }
    buildPanel();
  }

  async function buildPanel() {
    const job = currentJobInfo || extractJobInfo();
    const cust = currentCustomerInfo || extractCustomerInfo();
    currentJobInfo = job;
    currentCustomerInfo = cust;

    const stored = await getStored();
    const p = stored.profile || {};
    const loggedIn = !!(p && p.ownerName);

    const profileHTML = loggedIn
      ? `<div class="bb-profile-badge">
           <div class="bb-avatar">${getInitials(p.ownerName)}</div>
           <div><strong>${esc(p.ownerName)}</strong><span>${esc(p.bizName||'')}</span></div>
         </div>`
      : `<div class="bb-notice bb-notice--warn">
           No profile set up yet.
           <a href="#" id="bb-open-settings">Open Settings</a> to add your business info.
         </div>`;

    const panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="bb-panel">
        <div class="bb-panel__header">
          <div class="bb-panel__brand">
            <div class="bb-logo">BB</div>
            <div><h3>${BRAND} <span class="bb-accent">DocFill</span></h3></div>
          </div>
          <button class="bb-panel__close" id="bb-close" aria-label="Close panel">&times;</button>
        </div>
        <div class="bb-panel__body">
          <div class="bb-section">${profileHTML}</div>
          <div class="bb-divider"></div>

          <div class="bb-section">
            <h4>Client &amp; Job Details</h4>
            <div class="bb-field">
              <label for="bb-company">Client Company</label>
              <input id="bb-company" type="text" value="${esc(cust.company)}" placeholder="e.g. Smith Roofing LLC" maxlength="200"/>
            </div>
            <div class="bb-field">
              <label for="bb-name">Client Contact</label>
              <input id="bb-name" type="text" value="${esc(cust.customerName)}" placeholder="e.g. John Smith" maxlength="120"/>
            </div>
            <div class="bb-field">
              <label for="bb-job">Job Name</label>
              <input id="bb-job" type="text" value="${esc(job.jobName)}" placeholder="e.g. Roof Replacement — 123 Main" maxlength="200"/>
            </div>
            <div class="bb-field">
              <label for="bb-jobnum">Job #</label>
              <input id="bb-jobnum" type="text" value="${esc(job.jobNumber)}" placeholder="e.g. 4821" maxlength="30"/>
            </div>
          </div>

          <div class="bb-divider"></div>

          <div class="bb-section">
            <div class="bb-row">
              <h4>Description</h4>
              <button class="bb-btn bb-btn--copy" id="bb-copy-desc">Copy Description</button>
            </div>
            <p class="bb-hint">Paste into the Description field on your document.</p>
            <div class="bb-output" id="bb-desc-out" tabindex="0" role="textbox" aria-readonly="true" aria-label="Generated description text"></div>
          </div>

          <div class="bb-divider"></div>

          <div class="bb-section">
            <div class="bb-row">
              <h4>Footer</h4>
              <button class="bb-btn bb-btn--copy" id="bb-copy-footer">Copy Footer</button>
            </div>
            <p class="bb-hint">Paste into the Footer field on your document.</p>
            <div class="bb-output bb-output--sm" id="bb-footer-out" tabindex="0" role="textbox" aria-readonly="true" aria-label="Generated footer text"></div>
          </div>

          <div class="bb-section">
            <button class="bb-btn bb-btn--primary" id="bb-regen">Regenerate</button>
          </div>
        </div>
        <div class="bb-panel__footer">
          ${BRAND} DocFill v1.0 &nbsp;\u00B7&nbsp;
          <a href="https://mybetterboss.ai" target="_blank" rel="noopener">mybetterboss.ai</a>
        </div>
      </div>`;

    document.body.appendChild(panel);

    // Events
    document.getElementById('bb-close').addEventListener('click', () => panel.remove());
    document.getElementById('bb-regen').addEventListener('click', generate);
    document.getElementById('bb-copy-desc').addEventListener('click', function () {
      copyText(document.getElementById('bb-desc-out').getAttribute('data-raw')||'', this);
    });
    document.getElementById('bb-copy-footer').addEventListener('click', function () {
      copyText(document.getElementById('bb-footer-out').getAttribute('data-raw')||'', this);
    });

    const settingsLink = document.getElementById('bb-open-settings');
    if (settingsLink) {
      settingsLink.addEventListener('click', (e) => {
        e.preventDefault();
        chrome.runtime.sendMessage({ action: 'openOptions' });
      });
    }

    // Live re-generate on input (debounced)
    const debouncedGen = debounce(generate, 300);
    ['bb-company','bb-name','bb-job','bb-jobnum'].forEach(id => {
      document.getElementById(id).addEventListener('input', debouncedGen);
    });

    generate();
  }

  async function generate() {
    const stored = await getStored();
    const p = stored.profile || {};

    const data = {
      company:       document.getElementById('bb-company')?.value || '',
      customerName:  document.getElementById('bb-name')?.value || '',
      jobName:       document.getElementById('bb-job')?.value || '',
      jobNumber:     document.getElementById('bb-jobnum')?.value || '',
      jobAddress:    '', customerEmail: '', customerPhone: '',
      date:          new Date().toLocaleDateString(),
      bizName:       p.bizName || '',
      bizEmail:      p.bizEmail || '',
      bizPhone:      p.bizPhone || '',
      bizAddress:    p.bizAddress || '',
      bizWebsite:    p.bizWebsite || '',
      bizLicense:    p.bizLicense || '',
      ownerName:     p.ownerName || '',
    };

    const dT = stored.descriptionTemplate || getDefaultDescTemplate();
    const fT = stored.footerTemplate || getDefaultFooterTemplate();

    const descText   = render(dT, data);
    const footerText = render(fT, data);

    const dEl = document.getElementById('bb-desc-out');
    const fEl = document.getElementById('bb-footer-out');
    if (dEl) { dEl.setAttribute('data-raw', descText); dEl.textContent = descText; }
    if (fEl) { fEl.setAttribute('data-raw', footerText); fEl.textContent = footerText; }
  }

  // ---- Messages ----

  if (chrome && chrome.runtime) {
    chrome.runtime.onMessage.addListener((msg, _, reply) => {
      if (msg.action === 'getPageInfo') {
        reply({
          jobInfo: currentJobInfo || extractJobInfo(),
          customerInfo: currentCustomerInfo || extractCustomerInfo(),
          isRelevantPage: isRelevantPage(),
          url: window.location.href,
        });
        return false;
      }
      if (msg.action === 'togglePanel') {
        togglePanel();
        reply({ success: true });
        return false;
      }
    });
  }

  // ---- SPA URL Watcher ----

  function watchURL() {
    let last = window.location.href;
    const check = () => {
      if (window.location.href !== last) {
        last = window.location.href;
        currentJobInfo = currentCustomerInfo = null;
        const p = document.getElementById(PANEL_ID);
        if (p) p.remove();
        const b = document.getElementById(BUTTON_ID);
        if (b) b.remove();
        onPageChange();
      }
    };
    const origPush = history.pushState;
    history.pushState = function (...a) { origPush.apply(this, a); check(); };
    const origReplace = history.replaceState;
    history.replaceState = function (...a) { origReplace.apply(this, a); check(); };
    window.addEventListener('popstate', check);
  }

  function onPageChange() {
    if (!isExcludedPage() && isRelevantPage()) createFAB();
  }

  // ---- Init ----

  function init() {
    log('Init on', window.location.href);
    onPageChange();
    watchURL();
    // Debounced MutationObserver to prevent button duplication
    const debouncedCheck = debounce(() => {
      if (!document.getElementById(BUTTON_ID) && !isExcludedPage() && isRelevantPage()) {
        createFAB();
      }
    }, 500);
    const obs = new MutationObserver(debouncedCheck);
    obs.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
